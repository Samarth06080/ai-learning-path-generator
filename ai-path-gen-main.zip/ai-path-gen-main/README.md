# AI Path Generator
[ai-path-gen.vercel.app](https://ai-path-gen.vercel.app/)

This is an AI-powered learning path generator which suggests you the best learning path for you to learn new programming skills based on your current knowledge. It uses GPT-3.5 Turbo to generate the learning paths.

This is my first actual next.js and OpenAI project. I learned a lot while building. I hope you like it. There are a few corners short, but I will try to fix them.

<img width="1180" alt="Screenshot 2023-12-10 at 5 11 00 PM" src="https://github.com/dilpreetsinghaulakh/ai-path-gen/assets/77715510/788de1d7-ef67-4f9e-ae0b-27c7448c3cfc">
